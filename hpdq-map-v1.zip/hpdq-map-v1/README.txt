BẢN ĐỒ HỆ THỐNG ĐIỆN HPDQ — BẢN MẪU V1

1. Giải nén ZIP.
2. Mở thư mục trong VS Code, chạy bằng extension Live Server (Go Live).
   Hoặc dùng bất kỳ static web server được công ty cho phép.
3. Trình duyệt cần kết nối internet để tải thư viện Leaflet từ CDN.
4. Bấm "Chế độ chỉnh sửa" để thử thêm ghim trạm, vẽ tuyến cáp.
5. Tạo ít nhất 1 trạm 110 kV và 1 trạm 35 kV trước khi vẽ tuyến.
6. Khi vẽ tuyến: click lần lượt các điểm, bấm "Hoàn tất vẽ", chọn mã trạm nguồn và đích.
7. Click ghim trạm để bật/tắt tuyến và chọn Xem ảnh / Xem chi tiết.
8. Dữ liệu bản thử được lưu trong localStorage của TRÌNH DUYỆT HIỆN TẠI.
   Nhấn "Xuất bản sao JSON" để sao lưu; "Nhập bản sao JSON" để phục hồi.

CHƯA CÓ: xác thực quản trị thực, lưu đám mây, Google Sheets/Drive API,
đồng bộ nhiều thiết bị, phân quyền truy cập phía máy chủ, ảnh trạm thực,
hiệu ứng vẽ tuyến tuần tự. Các chức năng này sẽ triển khai tiếp.

CẢNH BÁO: Không đưa bản này lên hosting công khai với dữ liệu hạ tầng thực.
Nút chế độ chỉnh sửa hiện tại chỉ để demo, không bảo mật.

Ảnh nền được trích từ PDF người dùng cung cấp, giảm độ phân giải để chạy thử.
Tọa độ là tọa độ pixel trên ảnh, không phải GPS. Khi thay ảnh nền phải giữ
cùng hệ quy chiếu hoặc chuyển đổi tọa độ.
